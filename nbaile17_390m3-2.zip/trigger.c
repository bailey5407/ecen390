#include "trigger.h"
#include "buttons.h"
#include "mio.h"
#include "filter.h"
#include "transmitter.h"
#include "utils.h"
#include <stdbool.h>
#include <stdio.h>

#define DEBUG 1
#define TEST_DELAY 500

#define MIO_TRIGGER_PIN 10
#define TRIGGER_BUTTON BUTTONS_BTN0_MASK
#define GUN_TRIGGER_PRESSED 1

#define DEBOUNCE_PERIOD_SECONDS 5E-2
//given a sample rate of 100kHz and a determined debounce period, the number of debounce ticks is determined accodingly
#define DEBOUNCE_TICKS DEBOUNCE_PERIOD_SECONDS * FILTER_SAMPLE_FREQUENCY_IN_KHZ * 1000

#define DEFAULT_NUMBER_OF_SHOTS 100

//define states of trigger state machine and current_state to keep track
typedef enum{
    init_state,
    press_debounce_state,
    release_debounce_state
} trigger_st_t;

volatile static trigger_st_t current_state;

//flag to toggle ignoring gun input, this is because the pin is pull up, and we don't want to accidentally read values if no trigger is connected
volatile static bool ignoreGunInput;

//trigger pressed function returns true if either the trigger is pulled or button 0 is pressed
bool triggerPressed() {
	return ((!ignoreGunInput & (mio_readPin(MIO_TRIGGER_PIN) == GUN_TRIGGER_PRESSED)) || 
                (buttons_read() & BUTTONS_BTN0_MASK));
}

//keep track of instantaneous tigger value
volatile static bool trigger_pressed;

//keep track of elapsed ticks
volatile static uint16_t elapsed_ticks;

//trigger enable boolean
volatile static bool trigger_enabled;

//keep track of remaining shots
typedef uint16_t trigger_shotsRemaining_t;
volatile static trigger_shotsRemaining_t remaining_shots;

// Init trigger data-structures.
// Initializes the mio subsystem.
// Determines whether the trigger switch of the gun is connected
// (see discussion in lab web pages).
void trigger_init(){
    //initialize mio input pin
    ignoreGunInput = false;
    mio_init(false);
    mio_setPinAsInput(MIO_TRIGGER_PIN);
    if (triggerPressed()) {
    ignoreGunInput = true;
    }

    //initialize buttons
    buttons_init();

    //set current state to init state
    current_state = init_state;

    //set elapsed ticks to 0
    elapsed_ticks = 0;

    //set remaining shots
    trigger_setRemainingShotCount(DEFAULT_NUMBER_OF_SHOTS);
}

// Standard tick function.
void trigger_tick(){
    if(!trigger_enabled){
        return;
    }
    //state transitions
    switch(current_state){
        case init_state:
            //if trigger is pressed, move into debouncing state
            if(trigger_pressed = triggerPressed()){
                current_state = press_debounce_state;
            }
            break;
        case press_debounce_state:
            //once value has settled, reset ticks and move into state depending on settled value
            if(elapsed_ticks > DEBOUNCE_TICKS){
                elapsed_ticks = 0;
                if(trigger_pressed){
                    current_state = release_debounce_state;
                    if(DEBUG) printf("D\n");
                }
                else current_state = init_state;
            }
            break;
        case release_debounce_state:
            //once value has settled to released, reset ticks, fire if ammo remaining, and move into init state
            if(elapsed_ticks > DEBOUNCE_TICKS && !trigger_pressed){
                if(DEBUG) printf("U\n");
                elapsed_ticks = 0;
                current_state = init_state;
                if(remaining_shots > 0){
                    transmitter_run();
                    remaining_shots--;
                }
            }
            break;
    }
    //state actions
    switch(current_state){
        case init_state:
            //no actions
            break;
        case press_debounce_state:
            elapsed_ticks++;
            //if the stored value does not equal the current value, reset tick count and store curent value
            if(trigger_pressed != triggerPressed()){
                elapsed_ticks = 0;
                trigger_pressed = triggerPressed();
            }
            break;
        case release_debounce_state:
            elapsed_ticks++;
            //if the stored value does not equal the current value, reset tick count and store curent value
            if(trigger_pressed != triggerPressed()){
                elapsed_ticks = 0;
                trigger_pressed = triggerPressed();
            }
            break;
    }
}

// Enable the trigger state machine. The trigger state-machine is inactive until
// this function is called. This allows you to ignore the trigger when helpful
// (mostly useful for testing).
void trigger_enable(){
    trigger_enabled = true;
}

// Disable the trigger state machine so that trigger presses are ignored.
void trigger_disable(){
    trigger_enabled = false;
}

// Returns the number of remaining shots.
trigger_shotsRemaining_t trigger_getRemainingShotCount(){
    return remaining_shots;
}

// Sets the number of remaining shots.
void trigger_setRemainingShotCount(trigger_shotsRemaining_t count){
    remaining_shots = count;
}

// Runs the test continuously until BTN3 is pressed.
// The test just prints out a 'D' when the trigger or BTN0
// is pressed, and a 'U' when the trigger or BTN0 is released.
// Depends on the interrupt handler to call tick function.
void trigger_runTest(){
    trigger_enable();
    while(!(buttons_read() & BUTTONS_BTN3_MASK));
    trigger_disable();
    utils_msDelay(TEST_DELAY); //delay time between tests
    return;
}